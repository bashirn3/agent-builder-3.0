# K1 v7 test kit

What is in here
- `scenarios.md` / `scenarios.json`: all 827 scenarios (351 "devil" adversarial ones, plus usual, pilot, rigor, voice, leads, final) with the customer turns and the automatic checks. Readable without running anything.
- `tests/v2_scenarios.py`, `tests/v2_devil_extended.py`: where the scenarios are defined. `tests/v2_checks.py`: the checks (wrong language, ungrounded time or price, filler openers, tool misuse, claims of booking without a tool, and so on).
- `tools/k1-v2-eval.py`: the runner. It copies the candidate agent and booking workflows in n8n (ungated, no chat history writes), plays each scenario against Muster staging, cancels every test booking it made, and deletes the copies.
- `tools/k1-agent-v2-build.py`: builds the candidate workflows from `prompts/k1-business-prompt-v2.md` + `prompts/k1-conversational-head.md` and `tools/k1-muster-v2.js` (booking tool). `promote` copies the candidates over the live workflows (it backs the live ones up first).
- `tools/k1-variant-build.py`: builds a second agent candidate from a different base prompt, to compare prompts on the same suite (used for `prompts/dev-proposed-base-prompt.md`).
- `tools/k1-platform-version.py`, `tools/k1-history.py`: write the prompt into platform version 7 and record chats into the Test chats history.
- `results/`: the latest full run on the current candidate (non-booking: 654 scenario runs, booking: 173).

Running (needs n8n API access; set `N8N_RAPID_*` in `.env.local` as `n8n-gate.py` expects, plus the staging proxy variables used by `k1-agent-v2-build.py`)
```
python3 tools/k1-agent-v2-build.py build                      # candidates
python3 tools/k1-v2-eval.py run --suite all --books no --workers 4 --out out.json     # everything that does not need a real booking
python3 tools/k1-v2-eval.py run --suite all --books only --workers 3 --out book.json  # booking, move, cancel
python3 tools/k1-v2-eval.py run --suite devil --only handoff,inj --repeat 3 --out x.json
K1_EVAL_AGENT="K1 Muster agent dev-prompt (candidate)" python3 tools/k1-v2-eval.py run ...   # test another candidate
```
Notes
- Do not run the booking suite with many parallel workers: concurrent runs fight over the same early slots and produce false "slot just taken" failures. 3 workers is fine; rerun failures with 2.
- The models are not deterministic: a 1 to 3 percent residual flag rate run to run is normal. Re-run flagged scenarios with `--repeat` before calling something a defect.
- Some checks are deliberately strict (for example the filler-opener list), so read the reply before deciding it is a real defect.
